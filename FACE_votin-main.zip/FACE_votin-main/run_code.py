import sys
import os
import cv2
import face_recognition
import pickle
import json
from datetime import datetime
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QListWidget, QMessageBox, QStackedWidget, QInputDialog)
from PyQt5.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap, QFont
import serial
import serial.tools.list_ports

class RFIDReader(QThread):
    rfid_received = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.running = False
        self.serial_port = None
        
    def connect_uart(self, port='COM3', baudrate=9600):
        """Connect to UART port"""
        try:
            self.serial_port = serial.Serial(port, baudrate, timeout=1)
            return True
        except:
            return False
    
    def run(self):
        """Read RFID data from UART"""
        self.running = True
        while self.running:
            if self.serial_port and self.serial_port.in_waiting:
                try:
                    data = self.serial_port.readline().decode('utf-8').strip()
                    # Check if data matches RFID format xx:xx:xx:xx
                    if len(data.split(':')) == 4:
                        self.rfid_received.emit(data)
                except:
                    pass
            self.msleep(100)
    
    def stop(self):
        self.running = False
        if self.serial_port:
            self.serial_port.close()

class VotingSystem(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Secure Voting System with Face Recognition")
        self.setGeometry(100, 100, 1000, 700)
        
        # Directories
        self.known_faces_dir = "known_faces"
        self.data_dir = "voting_data"
        os.makedirs(self.known_faces_dir, exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Data files
        self.encodings_file = os.path.join(self.data_dir, "encodings.pkl")
        self.candidates_file = os.path.join(self.data_dir, "candidates.json")
        self.votes_file = os.path.join(self.data_dir, "votes.json")
        
        # Load data
        self.load_face_encodings()
        self.load_candidates()
        self.load_votes()
        
        # Camera
        self.camera = None
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        
        # RFID Reader
        self.rfid_reader = RFIDReader()
        self.rfid_reader.rfid_received.connect(self.process_rfid)
        
        self.init_ui()
        
    def init_ui(self):
        """Initialize the UI"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Title
        title = QLabel("Secure Voting System")
        title.setFont(QFont("Arial", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)
        
        # Stacked widget for different screens
        self.stacked_widget = QStackedWidget()
        main_layout.addWidget(self.stacked_widget)
        
        # Create screens
        self.create_home_screen()
        self.create_register_screen()
        self.create_voting_screen()
        self.create_settings_screen()
        
        # Navigation buttons
        nav_layout = QHBoxLayout()
        self.home_btn = QPushButton("Home")
        self.register_btn = QPushButton("Register Voter")
        self.vote_btn = QPushButton("Cast Vote")
        self.settings_btn = QPushButton("Settings")
        
        self.home_btn.clicked.connect(lambda: self.switch_screen(0))
        self.register_btn.clicked.connect(lambda: self.switch_screen(1))
        self.vote_btn.clicked.connect(lambda: self.switch_screen(2))
        self.settings_btn.clicked.connect(lambda: self.switch_screen(3))
        
        for btn in [self.home_btn, self.register_btn, self.vote_btn, self.settings_btn]:
            btn.setMinimumHeight(40)
            nav_layout.addWidget(btn)
        
        main_layout.addLayout(nav_layout)
        
    def create_home_screen(self):
        """Create home screen"""
        home = QWidget()
        layout = QVBoxLayout()
        home.setLayout(layout)
        
        welcome = QLabel("Welcome to the Secure Voting System")
        welcome.setFont(QFont("Arial", 18))
        welcome.setAlignment(Qt.AlignCenter)
        layout.addWidget(welcome)
        
        info = QLabel("• Register new voters with face recognition\n"
                     "• Cast votes securely with RFID verification\n"
                     "• Manage candidates in Settings\n"
                     "• Prevent double voting")
        info.setFont(QFont("Arial", 12))
        info.setAlignment(Qt.AlignCenter)
        layout.addWidget(info)
        
        layout.addStretch()
        self.stacked_widget.addWidget(home)
        
    def create_register_screen(self):
        """Create registration screen"""
        register = QWidget()
        layout = QVBoxLayout()
        register.setLayout(layout)
        
        # Camera feed
        self.register_camera_label = QLabel()
        self.register_camera_label.setMinimumSize(640, 480)
        self.register_camera_label.setAlignment(Qt.AlignCenter)
        self.register_camera_label.setStyleSheet("border: 2px solid black;")
        layout.addWidget(self.register_camera_label)
        
        # Name input
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Name:"))
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Enter your full name")
        name_layout.addWidget(self.name_input)
        layout.addLayout(name_layout)
        
        # Buttons
        btn_layout = QHBoxLayout()
        self.capture_btn = QPushButton("Capture Photo")
        self.capture_btn.clicked.connect(self.capture_and_register)
        self.capture_btn.setMinimumHeight(50)
        btn_layout.addWidget(self.capture_btn)
        layout.addLayout(btn_layout)
        
        self.stacked_widget.addWidget(register)
        
    def create_voting_screen(self):
        """Create voting screen"""
        voting = QWidget()
        layout = QVBoxLayout()
        voting.setLayout(layout)
        
        # RFID status
        self.rfid_status = QLabel("Waiting for RFID card...")
        self.rfid_status.setFont(QFont("Arial", 14))
        self.rfid_status.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.rfid_status)
        
        # Camera feed
        self.voting_camera_label = QLabel()
        self.voting_camera_label.setMinimumSize(640, 480)
        self.voting_camera_label.setAlignment(Qt.AlignCenter)
        self.voting_camera_label.setStyleSheet("border: 2px solid black;")
        layout.addWidget(self.voting_camera_label)
        
        # Voter info
        self.voter_info = QLabel("")
        self.voter_info.setFont(QFont("Arial", 12))
        self.voter_info.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.voter_info)
        
        # Candidates list
        self.candidates_list = QListWidget()
        self.candidates_list.setMaximumHeight(150)
        layout.addWidget(QLabel("Select Candidate:"))
        layout.addWidget(self.candidates_list)
        
        # Vote button
        self.submit_vote_btn = QPushButton("Submit Vote")
        self.submit_vote_btn.clicked.connect(self.submit_vote)
        self.submit_vote_btn.setEnabled(False)
        self.submit_vote_btn.setMinimumHeight(50)
        layout.addWidget(self.submit_vote_btn)
        
        # Start RFID and connect UART
        self.connect_uart_btn = QPushButton("Connect RFID Reader")
        self.connect_uart_btn.clicked.connect(self.connect_rfid_reader)
        self.connect_uart_btn.setMinimumHeight(40)
        layout.addWidget(self.connect_uart_btn)
        
        self.current_rfid = None
        self.current_voter = None
        
        self.stacked_widget.addWidget(voting)
        
    def create_settings_screen(self):
        """Create settings screen"""
        settings = QWidget()
        layout = QVBoxLayout()
        settings.setLayout(layout)
        
        layout.addWidget(QLabel("Manage Candidates"))
        
        # Candidates list
        self.settings_candidates_list = QListWidget()
        layout.addWidget(self.settings_candidates_list)
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Candidate")
        remove_btn = QPushButton("Remove Candidate")
        view_results_btn = QPushButton("View Results")
        
        add_btn.clicked.connect(self.add_candidate)
        remove_btn.clicked.connect(self.remove_candidate)
        view_results_btn.clicked.connect(self.view_results)
        
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(remove_btn)
        btn_layout.addWidget(view_results_btn)
        layout.addLayout(btn_layout)
        
        self.stacked_widget.addWidget(settings)
        
    def switch_screen(self, index):
        """Switch between screens"""
        # Stop camera when leaving screens
        if self.stacked_widget.currentIndex() in [1, 2]:
            self.stop_camera()
        
        self.stacked_widget.setCurrentIndex(index)
        
        # Start camera when entering register or voting screen
        if index == 1:
            self.start_camera(self.register_camera_label)
        elif index == 2:
            self.start_camera(self.voting_camera_label)
            self.update_candidates_list()
            self.reset_voting_state()
        elif index == 3:
            self.update_settings_candidates_list()
            
    def start_camera(self, label):
        """Start camera feed"""
        self.current_label = label
        self.camera = cv2.VideoCapture(0)
        if self.camera.isOpened():
            self.timer.start(30)
        else:
            QMessageBox.warning(self, "Error", "Could not access camera")
            
    def stop_camera(self):
        """Stop camera feed"""
        self.timer.stop()
        if self.camera:
            self.camera.release()
            self.camera = None
            
    def update_frame(self):
        """Update camera frame"""
        if self.camera and self.camera.isOpened():
            ret, frame = self.camera.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                # Detect faces for voting screen
                if self.stacked_widget.currentIndex() == 2 and self.current_rfid:
                    self.detect_and_display_face(frame)
                
                h, w, ch = frame.shape
                bytes_per_line = ch * w
                qt_image = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
                pixmap = QPixmap.fromImage(qt_image)
                self.current_label.setPixmap(pixmap.scaled(self.current_label.size(), Qt.KeepAspectRatio))
                
    def detect_and_display_face(self, frame):
        """Detect face in frame and identify voter"""
        rgb_frame = frame
        face_locations = face_recognition.face_locations(rgb_frame)
        
        if face_locations:
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
            
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(self.known_face_encodings, face_encoding, tolerance=0.6)
                
                if True in matches:
                    first_match_index = matches.index(True)
                    name = self.known_face_names[first_match_index]
                    self.current_voter = name
                    self.voter_info.setText(f"Voter Identified: {name}")
                    self.voter_info.setStyleSheet("color: green;")
                    self.submit_vote_btn.setEnabled(True)
                    return
        
        self.current_voter = None
        self.voter_info.setText("Face not recognized - Invalid vote")
        self.voter_info.setStyleSheet("color: red;")
        self.submit_vote_btn.setEnabled(False)
        
    def capture_and_register(self):
        """Capture photo and register voter"""
        name = self.name_input.text().strip()
        
        if not name:
            QMessageBox.warning(self, "Error", "Please enter a name")
            return
        
        if self.camera and self.camera.isOpened():
            ret, frame = self.camera.read()
            if ret:
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                face_locations = face_recognition.face_locations(rgb_frame)
                
                if not face_locations:
                    QMessageBox.warning(self, "Error", "No face detected. Please try again.")
                    return
                
                if len(face_locations) > 1:
                    QMessageBox.warning(self, "Error", "Multiple faces detected. Please ensure only one person is in frame.")
                    return
                
                # Get face encoding
                face_encoding = face_recognition.face_encodings(rgb_frame, face_locations)[0]
                
                # Save image
                image_path = os.path.join(self.known_faces_dir, f"{name}.jpg")
                cv2.imwrite(image_path, frame)
                
                # Add to known faces
                self.known_face_encodings.append(face_encoding)
                self.known_face_names.append(name)
                
                # Save encodings
                self.save_face_encodings()
                
                QMessageBox.information(self, "Success", f"Voter {name} registered successfully!")
                self.name_input.clear()
        
    def connect_rfid_reader(self):
        """Connect to RFID reader via UART"""
        # Get available ports
        ports = [port.device for port in serial.tools.list_ports.comports()]
        
        if not ports:
            QMessageBox.warning(self, "Error", "No serial ports available")
            return
        
        port, ok = QInputDialog.getItem(self, "Select Port", "Choose RFID Reader Port:", ports, 0, False)
        
        if ok and port:
            if self.rfid_reader.connect_uart(port):
                self.rfid_reader.start()
                QMessageBox.information(self, "Success", f"Connected to RFID reader on {port}")
                self.connect_uart_btn.setText("RFID Reader Connected")
                self.connect_uart_btn.setEnabled(False)
            else:
                QMessageBox.warning(self, "Error", f"Failed to connect to {port}")
                
    def process_rfid(self, rfid_data):
        """Process received RFID data"""
        self.current_rfid = rfid_data
        self.rfid_status.setText(f"RFID Detected: {rfid_data}")
        self.rfid_status.setStyleSheet("color: blue;")
        
        # Check if already voted
        if rfid_data in self.votes:
            QMessageBox.warning(self, "Invalid", "This RFID has already voted!")
            self.reset_voting_state()
        
    def submit_vote(self):
        """Submit the vote"""
        if not self.current_rfid:
            QMessageBox.warning(self, "Error", "No RFID detected")
            return
        
        if not self.current_voter:
            QMessageBox.warning(self, "Error", "Voter not recognized")
            return
        
        if self.current_rfid in self.votes:
            QMessageBox.warning(self, "Error", "This RFID has already voted")
            return
        
        selected_items = self.candidates_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Error", "Please select a candidate")
            return
        
        candidate = selected_items[0].text()
        
        # Record vote
        self.votes[self.current_rfid] = {
            "candidate": candidate,
            "voter": self.current_voter,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "rfid": self.current_rfid
        }
        
        self.save_votes()
        
        QMessageBox.information(self, "Success", f"Vote cast successfully!\nVoter: {self.current_voter}\nCandidate: {candidate}")
        self.reset_voting_state()
        
    def reset_voting_state(self):
        """Reset voting state"""
        self.current_rfid = None
        self.current_voter = None
        self.rfid_status.setText("Waiting for RFID card...")
        self.rfid_status.setStyleSheet("")
        self.voter_info.setText("")
        self.voter_info.setStyleSheet("")
        self.submit_vote_btn.setEnabled(False)
        self.candidates_list.clearSelection()
        
    def add_candidate(self):
        """Add a new candidate"""
        name, ok = QInputDialog.getText(self, "Add Candidate", "Enter candidate name:")
        if ok and name:
            if name not in self.candidates:
                self.candidates.append(name)
                self.save_candidates()
                self.update_settings_candidates_list()
                QMessageBox.information(self, "Success", f"Candidate {name} added")
            else:
                QMessageBox.warning(self, "Error", "Candidate already exists")
                
    def remove_candidate(self):
        """Remove a candidate"""
        selected = self.settings_candidates_list.currentItem()
        if selected:
            name = selected.text()
            self.candidates.remove(name)
            self.save_candidates()
            self.update_settings_candidates_list()
            QMessageBox.information(self, "Success", f"Candidate {name} removed")
        else:
            QMessageBox.warning(self, "Error", "Please select a candidate")
            
    def view_results(self):
        """View voting results"""
        if not self.votes:
            QMessageBox.information(self, "Results", "No votes cast yet")
            return
        
        results = {}
        for vote_data in self.votes.values():
            candidate = vote_data["candidate"]
            results[candidate] = results.get(candidate, 0) + 1
        
        result_text = "Voting Results:\n\n"
        for candidate, count in sorted(results.items(), key=lambda x: x[1], reverse=True):
            result_text += f"{candidate}: {count} votes\n"
        
        result_text += f"\nTotal votes: {len(self.votes)}"
        
        QMessageBox.information(self, "Results", result_text)
        
    def update_candidates_list(self):
        """Update candidates list in voting screen"""
        self.candidates_list.clear()
        self.candidates_list.addItems(self.candidates)
        
    def update_settings_candidates_list(self):
        """Update candidates list in settings screen"""
        self.settings_candidates_list.clear()
        self.settings_candidates_list.addItems(self.candidates)
        
    def load_face_encodings(self):
        """Load face encodings from file"""
        if os.path.exists(self.encodings_file):
            with open(self.encodings_file, 'rb') as f:
                data = pickle.load(f)
                self.known_face_encodings = data['encodings']
                self.known_face_names = data['names']
        else:
            self.known_face_encodings = []
            self.known_face_names = []
            
    def save_face_encodings(self):
        """Save face encodings to file"""
        data = {
            'encodings': self.known_face_encodings,
            'names': self.known_face_names
        }
        with open(self.encodings_file, 'wb') as f:
            pickle.dump(data, f)
            
    def load_candidates(self):
        """Load candidates from file"""
        if os.path.exists(self.candidates_file):
            with open(self.candidates_file, 'r') as f:
                self.candidates = json.load(f)
        else:
            self.candidates = []
            
    def save_candidates(self):
        """Save candidates to file"""
        with open(self.candidates_file, 'w') as f:
            json.dump(self.candidates, f, indent=4)
            
    def load_votes(self):
        """Load votes from file"""
        if os.path.exists(self.votes_file):
            with open(self.votes_file, 'r') as f:
                self.votes = json.load(f)
        else:
            self.votes = {}
            
    def save_votes(self):
        """Save votes to file"""
        with open(self.votes_file, 'w') as f:
            json.dump(self.votes, f, indent=4)
            
    def closeEvent(self, event):
        """Clean up on close"""
        self.stop_camera()
        self.rfid_reader.stop()
        self.rfid_reader.wait()
        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = VotingSystem()
    window.show()
    sys.exit(app.exec_())
