# Secure Voting System with Face Recognition

A comprehensive desktop voting application that combines facial recognition and RFID technology to ensure secure and fraud-free voting. Built with Python and PyQt5, this system prevents double voting while maintaining voter privacy and election integrity.

## Features

- **Biometric Authentication**: Face recognition using the `face_recognition` library for voter identification
- **RFID Integration**: Hardware-based voter verification via UART-connected RFID readers
- **Double Voting Prevention**: Tracks RFID cards to ensure each voter can only vote once
- **Candidate Management**: Easy-to-use interface for adding and removing candidates
- **Real-time Results**: View voting statistics and results at any time
- **User-Friendly Interface**: Clean PyQt5-based GUI with intuitive navigation
- **Data Persistence**: All voter registrations, candidates, and votes are stored locally

## System Architecture

The system consists of four main screens:

1. **Home**: Welcome screen with system overview
2. **Register Voter**: Camera-based face capture and voter registration
3. **Cast Vote**: RFID verification with face recognition for secure voting
4. **Settings**: Candidate management and results viewing

## Requirements

### Hardware
- Webcam for facial recognition
- RFID reader with UART interface (USB to Serial adapter)
- RFID cards/tags for voter identification

### Software Dependencies

```bash
pip install opencv-python
pip install face-recognition
pip install PyQt5
pip install pyserial
```

**Note**: The `face_recognition` library requires `dlib`, which may need additional setup:
- **Windows**: Install CMake and Visual Studio Build Tools
- **Linux**: `sudo apt-get install cmake`
- **macOS**: `brew install cmake`

## Installation

1. Clone or download the repository
2. Install required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Connect your RFID reader to an available COM/Serial port
4. Ensure your webcam is connected and functional

## Usage

### Starting the Application

```bash
python run_code.py
```

### Registering Voters

1. Navigate to **Register Voter** screen
2. Enter the voter's full name
3. Position the voter in front of the camera
4. Click **Capture Photo** to register
5. System will detect and save the facial encoding

**Important**: Ensure only one face is visible during registration

### Casting Votes

1. Navigate to **Cast Vote** screen
2. Click **Connect RFID Reader** and select the appropriate COM port
3. Scan the voter's RFID card
4. Position the voter in front of the camera for face verification
5. Once both RFID and face are verified, select a candidate
6. Click **Submit Vote**

The system will automatically prevent:
- Voting with an already-used RFID card
- Voting without proper face recognition match
- Voting without RFID verification

### Managing Candidates

1. Navigate to **Settings** screen
2. Use **Add Candidate** to add new candidates
3. Select and use **Remove Candidate** to delete candidates
4. Click **View Results** to see current vote tallies

## Data Storage

The system creates the following directories and files:

```
├── known_faces/          # Stores captured voter images
│   └── [voter_name].jpg
├── voting_data/          # Stores system data
│   ├── encodings.pkl     # Face recognition encodings
│   ├── candidates.json   # List of candidates
│   └── votes.json        # Voting records
```

## Security Features

- **Biometric Verification**: Each vote requires facial recognition match
- **RFID Tracking**: Prevents reuse of RFID cards
- **Timestamped Records**: All votes include timestamp for audit trails
- **Local Storage**: Data remains on the local machine
- **Face Encoding**: Stores mathematical representations, not images

## RFID Protocol

The system expects RFID data in the format: `xx:xx:xx:xx` (e.g., `AB:CD:EF:12`)

UART Configuration:
- Baud Rate: 9600
- Data Bits: 8
- Stop Bits: 1
- Parity: None

## Troubleshooting

### Camera Not Working
- Ensure no other application is using the camera
- Check camera permissions in your OS settings
- Try changing the camera index in `cv2.VideoCapture(0)` to `1` or `2`

### RFID Reader Not Connecting
- Verify the correct COM port is selected
- Check USB connection and drivers
- Ensure baud rate matches your RFID reader (default: 9600)

### Face Recognition Issues
- Ensure good lighting conditions
- Position face directly toward the camera
- Remove glasses or accessories that might obstruct facial features
- Adjust `tolerance` parameter in code for stricter/looser matching

### Installation Errors
If `face_recognition` fails to install:
```bash
pip install cmake
pip install dlib
pip install face-recognition
```

## Configuration

### Adjusting Face Recognition Tolerance

In the `detect_and_display_face()` method, modify the tolerance value:
```python
matches = face_recognition.compare_faces(self.known_face_encodings, 
                                         face_encoding, 
                                         tolerance=0.6)  # Lower = stricter
```

### Changing Default COM Port

Modify the `connect_uart()` call:
```python
self.rfid_reader.connect_uart(port='COM3', baudrate=9600)
```

## Limitations

- Requires good lighting for face recognition
- RFID reader must be UART-compatible
- Single concurrent user (not designed for multiple voting booths)
- Local storage only (no network/cloud integration)

## Future Enhancements

- Database integration for larger scale deployments
- Encrypted vote storage
- Admin authentication system
- Vote anonymization features
- Multi-booth network support
- Backup and restore functionality
- Detailed audit logs

## License

This project is provided as-is for educational and development purposes.

## Disclaimer

This system is designed for educational purposes and small-scale elections. For official government or large-scale elections, additional security measures, professional auditing, and compliance with local election laws are required.

## Support

For issues and questions:
- Check the Troubleshooting section
- Review the code comments for implementation details
- Ensure all hardware is properly connected and configured
